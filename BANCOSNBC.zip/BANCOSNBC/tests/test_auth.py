"""Autenticación unificada, roles y aislamiento entre clientes (Fases 1-2)."""
import pytest

from helpers_banco import ADMIN_PASSWORD, ADMIN_USUARIO, cabecera, saldo_de

MSG_GENERICO = "Usuario o contraseña incorrectos."


# ── Login unificado ──────────────────────────────────────────────────────────
def test_login_admin_devuelve_rol_admin(client):
    r = client.post("/api/auth/login", json={"identificador": ADMIN_USUARIO, "password": ADMIN_PASSWORD})
    d = r.get_json()
    assert r.status_code == 200 and d["ok"]
    assert d["data"]["rol"] == "admin" and d["data"]["token"]


def test_login_cliente_devuelve_rol_usuario_y_su_cuenta(client, crear_cliente):
    c = crear_cliente()
    r = client.post("/api/auth/login", json={"identificador": c.cuenta, "password": "uts" + c.cuenta})
    d = r.get_json()
    assert r.status_code == 200
    assert d["data"]["rol"] == "usuario" and d["data"]["numero_cuenta"] == c.cuenta


@pytest.mark.parametrize("identificador,password", [
    (ADMIN_USUARIO, "incorrecta"),      # admin con clave mala
    ("7001", "incorrecta"),             # cuenta con clave mala
    ("99999999", "uts99999999"),        # identificador inexistente
])
def test_login_fallido_da_401_con_mensaje_generico(client, crear_cliente, identificador, password):
    crear_cliente()
    r = client.post("/api/auth/login", json={"identificador": identificador, "password": password})
    assert r.status_code == 401
    # Mismo mensaje en todos los casos: no revela si el usuario existe.
    assert r.get_json()["mensaje"] == MSG_GENERICO


@pytest.mark.parametrize("body", [{}, {"identificador": "admin"}, {"password": "x"}, {"identificador": "", "password": ""}])
def test_login_con_campos_vacios_da_400(client, body):
    assert client.post("/api/auth/login", json=body).status_code == 400


def test_login_con_cuerpo_no_json_da_400(client):
    r = client.post("/api/auth/login", data="esto no es json", content_type="text/plain")
    assert r.status_code == 400 and r.get_json()["ok"] is False


def test_logout_invalida_el_token(client, crear_cliente):
    c = crear_cliente()
    assert client.get(f"/api/cuentas/movimientos/{c.cuenta}", headers=c.h).status_code == 200
    client.post("/api/auth/logout", headers=c.h)
    assert client.get(f"/api/cuentas/movimientos/{c.cuenta}", headers=c.h).status_code == 401


# ── Endpoints protegidos ─────────────────────────────────────────────────────
ENDPOINTS_PROTEGIDOS = [
    ("get", "/api/usuarios"), ("get", "/api/sucursales"), ("get", "/api/logs"),
    ("get", "/api/prestamos"), ("get", "/api/command/historial"),
    ("get", "/api/cuentas/estado/1001"),          # Fase 2: antes no exigía sesión
    ("get", "/api/cuentas/movimientos/1001"), ("get", "/api/cuentas/titular/1001"),
    ("post", "/api/operaciones/depositar"), ("post", "/api/operaciones/retirar"),
    ("post", "/api/operaciones/transferir"), ("post", "/api/usuarios/registrar"),
    ("post", "/api/prestamos/crear"),
]


@pytest.mark.parametrize("metodo,ruta", ENDPOINTS_PROTEGIDOS)
def test_sin_token_da_401(client, metodo, ruta):
    assert getattr(client, metodo)(ruta, json={}).status_code == 401


@pytest.mark.parametrize("metodo,ruta", ENDPOINTS_PROTEGIDOS[:5])
def test_token_falso_da_401(client, metodo, ruta):
    assert getattr(client, metodo)(ruta, headers=cabecera("token-inventado"), json={}).status_code == 401


ENDPOINTS_SOLO_ADMIN = [
    ("get", "/api/usuarios"), ("get", "/api/sucursales"), ("get", "/api/logs"),
    ("get", "/api/command/historial"),
    ("post", "/api/usuarios/registrar"), ("post", "/api/cuentas/crear"),
    ("post", "/api/cuentas/estado"), ("post", "/api/prestamos/crear"),
    ("post", "/api/prestamos/pagar"), ("post", "/api/prestamos/abonar"),
    ("delete", "/api/usuarios/eliminar"),
]


@pytest.mark.parametrize("metodo,ruta", ENDPOINTS_SOLO_ADMIN)
def test_cliente_no_accede_a_endpoints_de_admin(client, crear_cliente, metodo, ruta):
    c = crear_cliente()
    assert getattr(client, metodo)(ruta, headers=c.h, json={}).status_code == 403


def test_admin_si_accede_a_endpoints_de_admin(client, admin_h):
    assert client.get("/api/usuarios", headers=admin_h).status_code == 200
    assert client.get("/api/sucursales", headers=admin_h).status_code == 200


# ── Un cliente no puede tocar cuentas ajenas ─────────────────────────────────
def test_cliente_no_opera_cuenta_ajena(client, crear_cliente):
    a, b = crear_cliente(), crear_cliente()
    antes = saldo_de(client, b, b.h)

    intentos = [
        client.post("/api/operaciones/depositar", headers=a.h, json={"numero_cuenta": b.cuenta, "monto": 1000}),
        client.post("/api/operaciones/retirar", headers=a.h, json={"numero_cuenta": b.cuenta, "monto": 1000}),
        client.post("/api/operaciones/transferir", headers=a.h,
                    json={"numero_origen": b.cuenta, "numero_destino": a.cuenta, "monto": 1000}),
        client.get(f"/api/cuentas/movimientos/{b.cuenta}", headers=a.h),
    ]
    assert [r.status_code for r in intentos] == [403, 403, 403, 403]
    assert saldo_de(client, b, b.h) == antes


def test_cliente_si_puede_consultar_estado_de_cuenta_destino(client, crear_cliente):
    a, b = crear_cliente(), crear_cliente()
    r = client.get(f"/api/cuentas/estado/{b.cuenta}", headers=a.h)
    assert r.status_code == 200 and r.get_json()["data"]["estado"] == "activa"
