"""Umbral AML y detector de fraude (Fase 1: regresión del umbral)."""
import pytest

from config_banco import ConfigBanco
from cuenta import Cuenta
from detector_fraude import DetectorFraude


def test_umbral_aml_es_10_millones_cop():
    # Regresión: estaba en 10000 y generaba alerta en casi toda operación.
    assert ConfigBanco.get_instancia().get_limite_aml() == 10_000_000


@pytest.fixture
def cuenta():
    return Cuenta("T-AML", "ahorros", 100_000_000)


@pytest.mark.parametrize("monto", [10_000, 50_000, 2_000_000, 9_999_999.99, 10_000_000])
def test_montos_normales_no_generan_alerta_aml(cuenta, monto):
    segura, alertas = DetectorFraude.get_instancia().evaluar(cuenta, monto, "web", "deposito")
    assert segura and alertas == []


@pytest.mark.parametrize("monto", [10_000_000.01, 20_000_000, 500_000_000])
def test_montos_sobre_el_umbral_generan_alerta_aml(cuenta, monto):
    segura, alertas = DetectorFraude.get_instancia().evaluar(cuenta, monto, "web", "deposito")
    assert not segura and any("AML" in a for a in alertas)


def test_retiro_mayor_al_saldo_se_marca_como_no_seguro():
    cuenta = Cuenta("T-NEG", "ahorros", 1_000)
    segura, alertas = DetectorFraude.get_instancia().evaluar(cuenta, 2_000, "web", "retiro")
    assert not segura and any("saldo negativo" in a for a in alertas)


def test_deposito_de_50_mil_por_api_no_dispara_alerta_aml(client, crear_cliente, capsys):
    c = crear_cliente(saldo=1000)
    r = client.post("/api/operaciones/depositar", headers=c.h, json={"numero_cuenta": c.cuenta, "monto": 50_000})
    assert r.status_code == 200
    assert "excede límite AML" not in capsys.readouterr().out
