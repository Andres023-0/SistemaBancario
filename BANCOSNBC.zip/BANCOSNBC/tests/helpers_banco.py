"""Constantes y utilidades compartidas por los tests (se importan, a diferencia de conftest)."""

ADMIN_USUARIO = "admin"
ADMIN_PASSWORD = "bancouts2025"   # clave sembrada por defecto en la BD de pruebas


def cabecera(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


def saldo_de(client, cliente_o_numero, headers) -> float:
    numero = getattr(cliente_o_numero, "cuenta", cliente_o_numero)
    r = client.get(f"/api/cuentas/movimientos/{numero}", headers=headers)
    return r.get_json()["data"]["saldo"]
