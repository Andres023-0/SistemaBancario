"""
Fixtures comunes de los tests.

El aislamiento de la base de datos (BANCO_DB_PATH temporal) lo hace el
conftest.py de la raíz del proyecto, que pytest carga antes que este archivo.
"""
import itertools
import os
import sys
from dataclasses import dataclass

import pytest

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if RAIZ not in sys.path:
    sys.path.insert(0, RAIZ)

import api  # noqa: E402
import database  # noqa: E402
from helpers_banco import ADMIN_PASSWORD, ADMIN_USUARIO, cabecera  # noqa: E402

# Red de seguridad: si por cualquier motivo la app quedó conectada a la BD real,
# abortar antes de ejecutar un solo test.
assert os.path.abspath(database.RUTA_BD) != os.path.join(RAIZ, "banco.db"), (
    "Los tests NO pueden correr contra banco.db. Ejecuta pytest desde la raíz del "
    "proyecto para que se cargue su conftest.py de aislamiento."
)

_contador = itertools.count(1)



@dataclass
class Cliente:
    documento: str
    cuenta: str
    token: str

    @property
    def h(self) -> dict:
        return cabecera(self.token)


@pytest.fixture(scope="session")
def app():
    return api.app


@pytest.fixture
def client():
    return api.app.test_client()


@pytest.fixture(scope="session")
def admin_h():
    r = api.app.test_client().post(
        "/api/auth/login",
        json={"identificador": ADMIN_USUARIO, "password": ADMIN_PASSWORD},
    )
    return cabecera(r.get_json()["data"]["token"])


@pytest.fixture
def crear_cliente(client, admin_h):
    """Fábrica: crea usuario + KYC + cuenta y devuelve el cliente ya autenticado."""
    def _crear(saldo: float = 1_000_000, tipo: str = "ahorros") -> Cliente:
        n = next(_contador)
        documento, cuenta = f"9{n:08d}", f"{7000 + n}"
        r = client.post("/api/usuarios/registrar", headers=admin_h, json={
            "nombre": f"Cliente Test {n}", "documento": documento,
            "celular": "3000000000", "correo": f"t{n}@test.com"})
        assert r.status_code == 200, r.get_json()
        r = client.post("/api/usuarios/kyc", headers=admin_h, json={"documento": documento})
        assert r.status_code == 200, r.get_json()
        r = client.post("/api/cuentas/crear", headers=admin_h, json={
            "documento": documento, "numero": cuenta, "tipo": tipo,
            "saldo_inicial": saldo, "indice_sucursal": 1})
        assert r.status_code == 200, r.get_json()
        r = client.post("/api/auth/login", json={
            "identificador": cuenta, "password": "uts" + cuenta})
        assert r.status_code == 200, r.get_json()
        return Cliente(documento, cuenta, r.get_json()["data"]["token"])
    return _crear
