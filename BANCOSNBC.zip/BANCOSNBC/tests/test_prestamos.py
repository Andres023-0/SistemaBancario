"""Préstamos: cálculo exacto con Decimal (Fase 3), permisos y flujo por API."""
from decimal import Decimal, ROUND_HALF_UP
from fractions import Fraction

import pytest

from helpers_banco import saldo_de
from prestamo_strategy import EstrategiaInteresProducer

fijo = EstrategiaInteresProducer.get("fijo")
variable = EstrategiaInteresProducer.get("variable")


def cuota_de_referencia(monto, tasa_anual, n) -> float:
    """Implementación independiente: aritmética racional exacta + ROUND_HALF_UP."""
    capital = Fraction(str(monto))
    i = Fraction(str(tasa_anual)) / 100 / 12
    cuota = capital * i / (1 - (1 + i) ** -n)
    exacto = Decimal(cuota.numerator) / Decimal(cuota.denominator)
    return float(exacto.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


# ── Cálculo ──────────────────────────────────────────────────────────────────
@pytest.mark.parametrize("monto,tasa,n", [
    (5_000_000, 18.5, 12), (3_000_000, 20, 12), (10_000_000, 24.75, 36),
    (850_000.50, 17.2, 6), (120_000_000, 19.9, 120), (1_000, 1, 1),
])
def test_cuota_fija_coincide_con_referencia_exacta(monto, tasa, n):
    assert fijo.calcular_cuota(monto, tasa, n) == cuota_de_referencia(monto, tasa, n)


def test_cuota_conocida():
    assert fijo.calcular_cuota(3_000_000, 20, 12) == 277_903.52   # valor de un préstamo real del sistema


def test_redondeo_half_up_en_empates():
    # 2.675 / 1 = 2.675 exacto. ROUND_HALF_UP → 2.68 (round() de float daría 2.67).
    assert fijo.calcular_cuota(2.675, 0, 1) == 2.68


def test_tasa_cero_divide_en_partes_iguales():
    assert fijo.calcular_cuota(1200, 0, 12) == 100.0


def test_total_intereses_es_cuotas_menos_capital():
    cuota = fijo.calcular_cuota(5_000_000, 18.5, 12)
    assert fijo.calcular_total_intereses(5_000_000, 18.5, 12) == round(cuota * 12 - 5_000_000, 2)


def test_tasa_variable_tiene_piso_dtf_mas_spread():
    # Con tasa menor a 16.5 (12.5 + 4.0) se aplica 16.5.
    assert variable.calcular_cuota(1_000_000, 5, 12) == fijo.calcular_cuota(1_000_000, 16.5, 12)
    assert variable.calcular_cuota(1_000_000, 30, 12) == fijo.calcular_cuota(1_000_000, 30, 12)


def test_tipo_de_interes_invalido():
    with pytest.raises(ValueError):
        EstrategiaInteresProducer.get("inventado")


# ── API ──────────────────────────────────────────────────────────────────────
def crear_prestamo(client, admin_h, cliente, monto=3_000_000, cuotas=12, tasa=20, tipo="fijo"):
    return client.post("/api/prestamos/crear", headers=admin_h, json={
        "documento": cliente.documento, "numero_cuenta": cliente.cuenta,
        "monto": monto, "num_cuotas": cuotas, "tasa_anual": tasa, "tipo_interes": tipo})


def test_crear_prestamo_acredita_el_monto_en_la_cuenta(client, admin_h, crear_cliente):
    c = crear_cliente(saldo=1000)
    r = crear_prestamo(client, admin_h, c)
    assert r.status_code == 200
    d = r.get_json()["data"]
    assert d["cuota_mensual"] == 277_903.52 and d["cuotas_pagadas"] == 0 and d["estado"] == "activo"
    assert saldo_de(client, c, c.h) == 3_001_000.0


@pytest.mark.parametrize("cambio", [
    {"num_cuotas": "doce"}, {"num_cuotas": 361}, {"tasa_anual": 150}, {"tasa_anual": "x"},
    {"monto": "abc"}, {"monto": 1000.123},
])
def test_crear_prestamo_rechaza_datos_invalidos(client, admin_h, crear_cliente, cambio):
    c = crear_cliente()
    body = {"documento": c.documento, "numero_cuenta": c.cuenta, "monto": 1_000_000,
            "num_cuotas": 12, "tasa_anual": 20, "tipo_interes": "fijo", **cambio}
    r = client.post("/api/prestamos/crear", headers=admin_h, json=body)
    assert r.status_code == 400 and r.is_json


def test_no_se_presta_a_una_cuenta_de_otro_titular(client, admin_h, crear_cliente):
    a, b = crear_cliente(), crear_cliente()
    r = client.post("/api/prestamos/crear", headers=admin_h, json={
        "documento": a.documento, "numero_cuenta": b.cuenta, "monto": 1_000_000,
        "num_cuotas": 12, "tasa_anual": 20, "tipo_interes": "fijo"})
    assert r.status_code == 400 and "no pertenece" in r.get_json()["mensaje"]


def test_cliente_solo_ve_sus_prestamos(client, admin_h, crear_cliente):
    a, b = crear_cliente(), crear_cliente()
    crear_prestamo(client, admin_h, a)
    crear_prestamo(client, admin_h, b, monto=1_000_000)

    propios = client.get("/api/prestamos", headers=a.h).get_json()["data"]
    assert propios and all(p["numero_cuenta"] == a.cuenta for p in propios)
    todos = client.get("/api/prestamos", headers=admin_h).get_json()["data"]
    assert {p["numero_cuenta"] for p in todos} >= {a.cuenta, b.cuenta}


def test_pagar_cuota_y_abonar(client, admin_h, crear_cliente):
    c = crear_cliente()
    pid = crear_prestamo(client, admin_h, c).get_json()["data"]["id"]

    assert client.post("/api/prestamos/pagar", headers=admin_h, json={"prestamo_id": pid}).status_code == 200
    p = next(x for x in client.get("/api/prestamos", headers=c.h).get_json()["data"] if x["id"] == pid)
    assert p["cuotas_pagadas"] == 1 and p["total_pagado"] == 277_903.52

    assert client.post("/api/prestamos/abonar", headers=admin_h,
                       json={"prestamo_id": pid.lower(), "monto": 100_000.50}).status_code == 200
    p = next(x for x in client.get("/api/prestamos", headers=c.h).get_json()["data"] if x["id"] == pid)
    assert p["total_pagado"] == 377_904.02


def test_abonar_prestamo_inexistente_o_monto_invalido(client, admin_h):
    assert client.post("/api/prestamos/abonar", headers=admin_h, json={"prestamo_id": "NOEXISTE", "monto": 10}).status_code == 400
    assert client.post("/api/prestamos/abonar", headers=admin_h, json={"prestamo_id": "X", "monto": -1}).status_code == 400


def test_comparar_devuelve_las_dos_estrategias(client, admin_h):
    r = client.post("/api/prestamos/comparar", headers=admin_h, json={"monto": 5_000_000, "num_cuotas": 12, "tasa_anual": 18.5})
    datos = {d["tipo"]: d for d in r.get_json()["data"]}
    assert set(datos) == {"fijo", "variable"}
    assert datos["fijo"]["cuota_mensual"] == cuota_de_referencia(5_000_000, 18.5, 12)


def test_prestamo_persiste_en_la_base_de_datos(client, admin_h, crear_cliente):
    import api
    import prestamo_repository as pr
    c = crear_cliente()
    pid = crear_prestamo(client, admin_h, c).get_json()["data"]["id"]
    client.post("/api/prestamos/pagar", headers=admin_h, json={"prestamo_id": pid})
    with api.app.app_context():
        p = pr.obtener(pid)
        assert p is not None and p.cuotas_pagadas == 1 and p.cuota_mensual == 277_903.52
