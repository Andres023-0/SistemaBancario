"""Depósitos, retiros, transferencias, estados de cuenta y persistencia."""
import pytest

import api
from helpers_banco import saldo_de

DEP, RET, TRA = "/api/operaciones/depositar", "/api/operaciones/retirar", "/api/operaciones/transferir"


def test_deposito_incrementa_saldo_y_registra_movimiento(client, crear_cliente):
    c = crear_cliente(saldo=1000)
    r = client.post(DEP, headers=c.h, json={"numero_cuenta": c.cuenta, "monto": 250.50, "canal": "web"})
    assert r.status_code == 200
    d = client.get(f"/api/cuentas/movimientos/{c.cuenta}", headers=c.h).get_json()["data"]
    assert d["saldo"] == 1250.50
    ultimo = d["movimientos"][-1]
    assert ultimo["monto"] == 250.50 and ultimo["saldo_final"] == 1250.50


def test_retiro_descuenta_saldo(client, crear_cliente):
    c = crear_cliente(saldo=1000)
    assert client.post(RET, headers=c.h, json={"numero_cuenta": c.cuenta, "monto": 300, "canal": "cajero"}).status_code == 200
    assert saldo_de(client, c, c.h) == 700.0


def test_retiro_con_saldo_insuficiente_se_rechaza_sin_cambiar_saldo(client, crear_cliente):
    c = crear_cliente(saldo=1000)
    r = client.post(RET, headers=c.h, json={"numero_cuenta": c.cuenta, "monto": 1000.01, "canal": "web"})
    assert r.status_code == 400 and "insuficiente" in r.get_json()["mensaje"].lower()
    assert saldo_de(client, c, c.h) == 1000.0


def test_retiro_del_saldo_exacto_deja_la_cuenta_en_cero(client, crear_cliente):
    c = crear_cliente(saldo=1000)
    assert client.post(RET, headers=c.h, json={"numero_cuenta": c.cuenta, "monto": 1000, "canal": "web"}).status_code == 200
    assert saldo_de(client, c, c.h) == 0.0


def test_transferencia_mueve_fondos_y_conserva_el_total(client, crear_cliente):
    a, b = crear_cliente(saldo=5000), crear_cliente(saldo=100)
    r = client.post(TRA, headers=a.h, json={"numero_origen": a.cuenta, "numero_destino": b.cuenta, "monto": 1234.56, "canal": "web"})
    assert r.status_code == 200
    sa, sb = saldo_de(client, a, a.h), saldo_de(client, b, b.h)
    assert (sa, sb) == (3765.44, 1334.56)
    assert round(sa + sb, 2) == 5100.00


def test_transferencia_sin_fondos_no_mueve_nada(client, crear_cliente):
    a, b = crear_cliente(saldo=100), crear_cliente(saldo=100)
    r = client.post(TRA, headers=a.h, json={"numero_origen": a.cuenta, "numero_destino": b.cuenta, "monto": 500, "canal": "web"})
    assert r.status_code == 400
    assert (saldo_de(client, a, a.h), saldo_de(client, b, b.h)) == (100.0, 100.0)


def test_transferencia_a_cuenta_inexistente(client, crear_cliente):
    a = crear_cliente(saldo=100)
    r = client.post(TRA, headers=a.h, json={"numero_origen": a.cuenta, "numero_destino": "00000", "monto": 10})
    assert r.status_code == 400 and "no encontrada" in r.get_json()["mensaje"]
    assert saldo_de(client, a, a.h) == 100.0


def test_operacion_sobre_cuenta_inexistente(client, admin_h):
    r = client.post(DEP, headers=admin_h, json={"numero_cuenta": "00000", "monto": 10})
    assert r.status_code == 400 and "no encontrada" in r.get_json()["mensaje"]


def test_decimales_exactos_en_sumas_repetidas(client, crear_cliente):
    # En float, 0.1 + 0.2 = 0.30000000000000004. Aquí el saldo debe ser exacto.
    c = crear_cliente(saldo=0)
    for monto in (0.10, 0.20):
        client.post(DEP, headers=c.h, json={"numero_cuenta": c.cuenta, "monto": monto})
    assert saldo_de(client, c, c.h) == 0.30
    for _ in range(10):
        client.post(DEP, headers=c.h, json={"numero_cuenta": c.cuenta, "monto": 0.01})
    assert saldo_de(client, c, c.h) == 0.40


# ── Estados de cuenta (patrón State) ─────────────────────────────────────────
def test_cuenta_bloqueada_rechaza_operaciones_y_se_reactiva(client, crear_cliente, admin_h):
    c = crear_cliente(saldo=1000)
    r = client.post("/api/cuentas/estado", headers=admin_h,
                    json={"numero_cuenta": c.cuenta, "nuevo_estado": "bloqueada", "motivo": "test"})
    assert r.status_code == 200

    assert client.post(DEP, headers=c.h, json={"numero_cuenta": c.cuenta, "monto": 100}).status_code == 400
    assert client.post(RET, headers=c.h, json={"numero_cuenta": c.cuenta, "monto": 100}).status_code == 400
    assert saldo_de(client, c, c.h) == 1000.0

    client.post("/api/cuentas/estado", headers=admin_h, json={"numero_cuenta": c.cuenta, "nuevo_estado": "activa"})
    assert client.post(DEP, headers=c.h, json={"numero_cuenta": c.cuenta, "monto": 100}).status_code == 200
    assert saldo_de(client, c, c.h) == 1100.0


def test_cuenta_cerrada_es_estado_terminal(client, crear_cliente, admin_h):
    c = crear_cliente()
    client.post("/api/cuentas/estado", headers=admin_h, json={"numero_cuenta": c.cuenta, "nuevo_estado": "cerrada"})
    r = client.post("/api/cuentas/estado", headers=admin_h, json={"numero_cuenta": c.cuenta, "nuevo_estado": "activa"})
    assert r.status_code == 400 and "cerrada" in r.get_json()["mensaje"]


def test_estado_invalido_se_rechaza(client, crear_cliente, admin_h):
    c = crear_cliente()
    r = client.post("/api/cuentas/estado", headers=admin_h, json={"numero_cuenta": c.cuenta, "nuevo_estado": "inventado"})
    assert r.status_code == 400


# ── Command: deshacer ────────────────────────────────────────────────────────
def test_deshacer_revierte_el_ultimo_deposito(client, crear_cliente, admin_h):
    c = crear_cliente(saldo=1000)
    client.post(DEP, headers=c.h, json={"numero_cuenta": c.cuenta, "monto": 400})
    assert saldo_de(client, c, c.h) == 1400.0
    r = client.post("/api/command/deshacer", headers=admin_h)
    assert r.status_code == 200
    assert saldo_de(client, c, c.h) == 1000.0


# ── Alta de usuarios y cuentas ───────────────────────────────────────────────
def test_no_se_puede_registrar_documento_duplicado(client, admin_h, crear_cliente):
    c = crear_cliente()
    r = client.post("/api/usuarios/registrar", headers=admin_h, json={"nombre": "Otro", "documento": c.documento})
    assert r.status_code == 400 and "Ya existe" in r.get_json()["mensaje"]


def test_no_se_puede_crear_cuenta_sin_kyc(client, admin_h):
    client.post("/api/usuarios/registrar", headers=admin_h, json={"nombre": "Sin KYC", "documento": "80000001"})
    r = client.post("/api/cuentas/crear", headers=admin_h, json={"documento": "80000001", "numero": "6801", "saldo_inicial": 0})
    assert r.status_code == 400


def test_no_se_puede_duplicar_numero_de_cuenta(client, admin_h, crear_cliente):
    c = crear_cliente()
    client.post("/api/usuarios/registrar", headers=admin_h, json={"nombre": "Otro", "documento": "80000002"})
    client.post("/api/usuarios/kyc", headers=admin_h, json={"documento": "80000002"})
    r = client.post("/api/cuentas/crear", headers=admin_h, json={"documento": "80000002", "numero": c.cuenta, "saldo_inicial": 0})
    assert r.status_code == 400


# ── Persistencia: lo que dice la API es lo que hay en la base de datos ───────
def test_los_saldos_se_persisten_en_la_base_de_datos(client, crear_cliente):
    import cuenta_repository as cr
    a, b = crear_cliente(saldo=2000), crear_cliente(saldo=500)
    client.post(DEP, headers=a.h, json={"numero_cuenta": a.cuenta, "monto": 100.25})
    client.post(RET, headers=a.h, json={"numero_cuenta": a.cuenta, "monto": 50})
    client.post(TRA, headers=a.h, json={"numero_origen": a.cuenta, "numero_destino": b.cuenta, "monto": 300.10})

    with api.app.app_context():
        desde_bd_a = cr.obtener(a.cuenta)
        desde_bd_b = cr.obtener(b.cuenta)
        assert desde_bd_a.saldo == saldo_de(client, a, a.h) == 1750.15
        assert desde_bd_b.saldo == saldo_de(client, b, b.h) == 800.10
        # El historial guardado en BD es idéntico, en contenido y orden, al de la API.
        api_a = client.get(f"/api/cuentas/movimientos/{a.cuenta}", headers=a.h).get_json()["data"]
        assert desde_bd_a.transacciones[-20:] == api_a["movimientos"]
        assert len(desde_bd_a.transacciones) == api_a["total_movimientos"]


# ── Defecto conocido (pendiente de decisión) ─────────────────────────────────
@pytest.mark.xfail(strict=True, reason=(
    "Cuenta.transferir() llama a retirar(), que ya registra un 'retiro', y luego "
    "registra además una 'transferencia': cada transferencia queda duplicada en el "
    "historial de la cuenta origen (y los observadores se disparan dos veces). "
    "Al corregirlo este test pasará y strict=True obligará a quitar este marcador."))
def test_transferencia_registra_un_solo_movimiento_en_el_origen(client, crear_cliente):
    a, b = crear_cliente(saldo=1000), crear_cliente(saldo=0)
    antes = client.get(f"/api/cuentas/movimientos/{a.cuenta}", headers=a.h).get_json()["data"]["total_movimientos"]
    client.post(TRA, headers=a.h, json={"numero_origen": a.cuenta, "numero_destino": b.cuenta, "monto": 100})
    despues = client.get(f"/api/cuentas/movimientos/{a.cuenta}", headers=a.h).get_json()["data"]["total_movimientos"]
    assert despues - antes == 1
