"""Validación de entradas y manejo de errores (Fase 3)."""
import pytest

import api
from validaciones import ErrorValidacion, entero, monto_valido, tasa_valida, texto

DEPOSITO = "/api/operaciones/depositar"


# ── Funciones puras ──────────────────────────────────────────────────────────
@pytest.mark.parametrize("valor,esperado", [
    (100, 100.0), (1250.75, 1250.75), ("500", 500.0), ("1e3", 1000.0),
    (0.1, 0.1), (999_999_999_999.99, 999_999_999_999.99), (None, 0.0), ("", 0.0),
])
def test_monto_valido_acepta(valor, esperado):
    assert monto_valido({"monto": valor}) == esperado


@pytest.mark.parametrize("valor", [
    "abc", "1,5", [1], {"a": 1}, True, float("nan"), float("inf"), "NaN", "Infinity",
    10.005, "0.001", 1e30, 1_000_000_000_000,
])
def test_monto_valido_rechaza(valor):
    with pytest.raises(ErrorValidacion):
        monto_valido({"monto": valor})


def test_monto_valido_respeta_minimo():
    with pytest.raises(ErrorValidacion):
        monto_valido({"monto": -1}, minimo=0)
    assert monto_valido({"monto": 0}, minimo=0) == 0.0


def test_monto_texto_y_numero_equivalentes():
    assert monto_valido({"monto": "0.30"}) == monto_valido({"monto": 0.3}) == 0.3


@pytest.mark.parametrize("valor,esperado", [(12, 12), ("12", 12), (12.0, 12), (None, 5), ("", 5)])
def test_entero_acepta(valor, esperado):
    assert entero({"n": valor}, "n", defecto=5) == esperado


@pytest.mark.parametrize("valor", ["abc", 12.5, True, [1], float("nan"), "1.5"])
def test_entero_rechaza(valor):
    with pytest.raises(ErrorValidacion):
        entero({"n": valor}, "n")


def test_entero_respeta_rango():
    with pytest.raises(ErrorValidacion):
        entero({"n": 0}, "n", minimo=1)
    with pytest.raises(ErrorValidacion):
        entero({"n": 361}, "n", maximo=360)


@pytest.mark.parametrize("valor", [100, 150, "x", 99.99999])
def test_tasa_rechaza(valor):
    with pytest.raises(ErrorValidacion):
        tasa_valida({"t": valor}, "t")


def test_tasa_acepta():
    assert tasa_valida({"t": 18.5}, "t") == 18.5


def test_texto_acepta_str_e_int_y_recorta():
    assert texto({"c": "  1001 "}, "c") == "1001"
    assert texto({"c": 1001}, "c") == "1001"
    assert texto({}, "c", "web") == "web"


@pytest.mark.parametrize("valor", [["1"], {"a": 1}, True, 1.5, "x" * 101])
def test_texto_rechaza(valor):
    with pytest.raises(ErrorValidacion):
        texto({"c": valor}, "c")


# ── A través de la API: siempre 400 + JSON, nunca 500/HTML ───────────────────
@pytest.mark.parametrize("monto", ["abc", [1], True, "NaN", "Infinity", 10.005, 1e30, "1000,50"])
def test_api_rechaza_montos_invalidos_con_400(client, crear_cliente, monto):
    c = crear_cliente()
    r = client.post(DEPOSITO, headers=c.h, json={"numero_cuenta": c.cuenta, "monto": monto})
    assert r.status_code == 400
    assert r.is_json and r.get_json()["ok"] is False


def test_monto_invalido_no_modifica_saldo(client, crear_cliente):
    c = crear_cliente(saldo=5000)
    client.post(DEPOSITO, headers=c.h, json={"numero_cuenta": c.cuenta, "monto": 10.005})
    r = client.get(f"/api/cuentas/movimientos/{c.cuenta}", headers=c.h)
    assert r.get_json()["data"]["saldo"] == 5000.0


@pytest.mark.parametrize("monto", [0, -5, None])
def test_api_conserva_mensaje_de_monto_no_positivo(client, crear_cliente, monto):
    c = crear_cliente()
    r = client.post(DEPOSITO, headers=c.h, json={"numero_cuenta": c.cuenta, "monto": monto})
    assert r.status_code == 400 and "monto positivo" in r.get_json()["mensaje"]


@pytest.mark.parametrize("body", [[1, 2, 3], "texto", 5])
def test_api_rechaza_cuerpo_que_no_es_objeto(client, crear_cliente, body):
    c = crear_cliente()
    r = client.post(DEPOSITO, headers=c.h, json=body)
    assert r.status_code == 400 and r.is_json


def test_api_rechaza_numero_cuenta_con_tipo_invalido(client, crear_cliente):
    c = crear_cliente()
    r = client.post(DEPOSITO, headers=c.h, json={"numero_cuenta": ["1"], "monto": 100})
    assert r.status_code == 400


def test_api_acepta_numero_cuenta_como_entero(client, crear_cliente):
    c = crear_cliente()
    r = client.post(DEPOSITO, headers=c.h, json={"numero_cuenta": int(c.cuenta), "monto": 100})
    assert r.status_code == 200


@pytest.mark.parametrize("body", [
    {"saldo_inicial": -1}, {"saldo_inicial": "x"}, {"indice_sucursal": "x"}, {"indice_sucursal": 2.5},
])
def test_crear_cuenta_valida_entradas(client, admin_h, body):
    base = {"documento": "1", "numero": "6999"}
    assert client.post("/api/cuentas/crear", headers=admin_h, json={**base, **body}).status_code == 400


# ── Errores globales en JSON ─────────────────────────────────────────────────
def test_ruta_inexistente_responde_404_en_json(client):
    r = client.get("/api/ruta-que-no-existe")
    assert r.status_code == 404 and r.is_json and r.get_json()["ok"] is False


def test_metodo_no_permitido_responde_405_en_json(client):
    r = client.get("/api/auth/login")
    assert r.status_code == 405 and r.is_json


def test_error_inesperado_da_500_json_sin_filtrar_detalles(client, admin_h, monkeypatch):
    def explota(_numero):
        raise RuntimeError("detalle-interno-secreto")
    monkeypatch.setattr(api.banco, "buscar_cuenta_por_numero", explota)
    r = client.post(DEPOSITO, headers=admin_h, json={"numero_cuenta": "1", "monto": 10})
    assert r.status_code == 500 and r.is_json
    assert r.get_json()["mensaje"] == "Error interno del servidor."
    assert "detalle-interno-secreto" not in r.get_data(as_text=True)
