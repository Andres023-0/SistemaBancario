from cuenta import Cuenta
from logger import Logger


class CuentaPrototypeRegistry:
    """
    Patrón Prototype — Registro de prototipos.
    Actúa como catálogo de cuentas plantilla ya configuradas y válidas.
    El cliente registra una cuenta base y luego solicita clones de ella
    sin conocer los detalles internos de construcción.

    PULIDO: antes, _prototipos vivía solo como diccionario de clase (en
    memoria) — cualquier prototipo registrado se perdía al reiniciar
    api.py. Ahora se respalda en la tabla `prototipos_cuenta`
    (prototipo_repository.py). Solo se guardan tipo y saldo: son los
    únicos datos que Cuenta.clone() usa realmente como plantilla — el
    número, los observadores, el estado y las transacciones se resetean
    en cada clon sin importar de dónde vino el prototipo.

    Uso (sin cambios frente a como ya se usaba en el resto del proyecto):
        CuentaPrototypeRegistry.registrar("ahorros_estandar", cuenta)
        proto = CuentaPrototypeRegistry.get("ahorros_estandar")
        nueva = (CuentaBuilder()
            .numero("3002")
            .asociar_usuario(usuario)
            .asociar_sucursal(sucursal)
            .clone_desde(proto))
    """

    _prototipos: dict[str, Cuenta] = {}
    _cargado = False

    # ── Carga perezosa desde la BD ───────────────────────────────────────────

    @classmethod
    def _asegurar_cargado(cls):
        """
        Puebla _prototipos desde la base de datos la primera vez que se
        usa el registro en este proceso. Idempotente: si ya se cargó
        (o si un prototipo se registró antes de leer nada), no repite la
        consulta.
        """
        if cls._cargado:
            return
        cls._cargado = True

        import prototipo_repository as pr
        for nombre, (tipo, saldo) in pr.listar_todos().items():
            if nombre in cls._prototipos:
                continue
            # Cuenta placeholder: el número no importa (clone() lo
            # sobrescribe siempre), solo interesan tipo y saldo.
            cls._prototipos[nombre] = Cuenta("__proto__", tipo, saldo)

    # ── Registro ──────────────────────────────────────────────────────────────

    @classmethod
    def registrar(cls, nombre: str, cuenta: Cuenta):
        """
        Guarda una cuenta como prototipo bajo un nombre clave.
        Si ya existía un prototipo con ese nombre, lo sobreescribe
        y notifica en el log. Persiste en la base de datos.
        """
        cls._asegurar_cargado()

        if not nombre or not isinstance(nombre, str):
            raise ValueError("El nombre del prototipo no puede estar vacío")

        existia = nombre in cls._prototipos
        cls._prototipos[nombre] = cuenta

        import prototipo_repository as pr
        pr.guardar(nombre, cuenta.tipo, cuenta.saldo)

        Logger.get_instancia().log(
            f"[PROTOTYPE] Prototipo '{ nombre }' "
            f"{'actualizado' if existia else 'registrado'} — "
            f"tipo: {cuenta.tipo} | saldo: ${cuenta.saldo:,.2f}",
            nivel="INFO"
        )

    # ── Consulta ──────────────────────────────────────────────────────────────

    @classmethod
    def get(cls, nombre: str) -> Cuenta:
        """
        Retorna la cuenta prototipo registrada bajo ese nombre.
        Lanza ValueError si no existe, listando los disponibles
        para orientar al usuario.
        """
        cls._asegurar_cargado()

        if nombre not in cls._prototipos:
            disponibles = cls.listar()
            raise ValueError(
                f"Prototipo '{nombre}' no existe. "
                f"Disponibles: {disponibles if disponibles else '(ninguno aún)'}"
            )
        return cls._prototipos[nombre]

    @classmethod
    def listar(cls) -> list[str]:
        """Retorna los nombres de todos los prototipos registrados."""
        cls._asegurar_cargado()
        return list(cls._prototipos.keys())

    @classmethod
    def eliminar(cls, nombre: str):
        """
        Elimina un prototipo del registro (memoria y base de datos).
        Útil si una cuenta plantilla queda obsoleta.
        """
        cls._asegurar_cargado()

        if nombre not in cls._prototipos:
            raise ValueError(f"Prototipo '{nombre}' no existe, no se puede eliminar")
        del cls._prototipos[nombre]

        import prototipo_repository as pr
        pr.eliminar(nombre)

        Logger.get_instancia().log(
            f"[PROTOTYPE] Prototipo '{nombre}' eliminado del registro",
            nivel="INFO"
        )

    @classmethod
    def mostrar_todos(cls):
        """
        Imprime en el log el estado completo del registro.
        Útil para la opción de depuración del menú.
        """
        cls._asegurar_cargado()

        logger = Logger.get_instancia()
        if not cls._prototipos:
            logger.log("[PROTOTYPE] No hay prototipos registrados.", nivel="INFO")
            return
        logger.log(f"[PROTOTYPE] Prototipos registrados ({len(cls._prototipos)}):", nivel="INFO")
        for nombre, cuenta in cls._prototipos.items():
            logger.log(
                f"  • '{nombre}' → tipo: {cuenta.tipo} | "
                f"saldo: ${cuenta.saldo:,.2f} | "
                f"número base: {cuenta.numero}",
                nivel="INFO"
            )
