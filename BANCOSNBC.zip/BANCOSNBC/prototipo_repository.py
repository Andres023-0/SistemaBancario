"""
=============================================================================
REPOSITORIO DE PROTOTIPOS DE CUENTA
=============================================================================
Traduce entre la tabla `prototipos_cuenta` y lo que necesita
CuentaPrototypeRegistry (cuenta_prototype.py) para seguir funcionando
exactamente igual que antes, pero sobreviviendo a un reinicio de api.py.
=============================================================================
"""

import models
from database import db


def guardar(nombre: str, tipo: str, saldo: float) -> None:
    fila = db.session.get(models.PrototipoCuenta, nombre)
    if fila is None:
        fila = models.PrototipoCuenta(nombre=nombre)
        db.session.add(fila)
    fila.tipo = tipo
    fila.saldo = saldo
    db.session.commit()


def listar_todos() -> dict:
    """Retorna {nombre: (tipo, saldo)} de todos los prototipos guardados."""
    filas = models.PrototipoCuenta.query.all()
    return {f.nombre: (f.tipo, float(f.saldo)) for f in filas}


def eliminar(nombre: str) -> bool:
    fila = db.session.get(models.PrototipoCuenta, nombre)
    if fila is None:
        return False
    db.session.delete(fila)
    db.session.commit()
    return True
