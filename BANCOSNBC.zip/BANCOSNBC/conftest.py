"""
Protección raíz para pytest — se carga SIEMPRE que se ejecuta pytest sobre este
proyecto, sin importar desde qué directorio se lance.

1. Aísla la base de datos: define BANCO_DB_PATH apuntando a una BD temporal
   ANTES de que se importe cualquier módulo del proyecto, así ningún test (ni
   ningún script que se importe por accidente) puede tocar banco.db.
2. Ignora test_fase8/9/10.py: son scripts de verificación manual que ejecutan
   código al importarse (crean usuarios, cambian la clave del admin...). Se
   siguen corriendo a mano con `python test_fase8.py`.
"""
import os
import shutil
import tempfile

collect_ignore = ["test_fase8.py", "test_fase9.py", "test_fase10.py"]

_DIR_TMP = tempfile.mkdtemp(prefix="bancotest_")
os.environ["BANCO_DB_PATH"] = os.path.join(_DIR_TMP, "test_banco.db")
os.environ.pop("FLASK_DEBUG", None)


def pytest_sessionfinish(session, exitstatus):
    shutil.rmtree(_DIR_TMP, ignore_errors=True)
