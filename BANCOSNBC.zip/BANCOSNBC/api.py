from flask import Flask, jsonify, request, g
from flask_cors import CORS
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from database import init_db, crear_tablas, db
from flask_migrate import Migrate
from banco import Banco
from logger import Logger
from sucursales_manager import SucursalesManager
from cuenta_prototype import CuentaPrototypeRegistry
from cuenta_builder import CuentaBuilder
from transaccion import Transaccion
from operacion_facade import OperacionFacade
from usuario_facade import UsuarioFacade
from auth_session import SesionManager, requiere_sesion
from validaciones import ErrorValidacion, leer_json, texto, monto_valido, tasa_valida, entero
from werkzeug.exceptions import HTTPException

app = Flask(__name__)
# Orígenes permitidos para el frontend. Por defecto "*" (desarrollo local);
# en un despliegue real, definir CORS_ORIGINS="https://mi-dominio.com".
# La API usa tokens Bearer (no cookies), por lo que "*" no habilita CSRF.
CORS(app, origins=[o.strip() for o in os.environ.get("CORS_ORIGINS", "*").split(",")])

# =============================================================================
# FASE 12 — CONEXIÓN REAL A LA BASE DE DATOS
# =============================================================================
# Antes, Banco(), GestorPrestamos y SucursalesManager empezaban siempre
# vacíos en memoria, y seed.py/seed_prestamos.py los volvían a llenar en
# CADA arranque. Ahora:
#   1. init_db(app) conecta Flask-SQLAlchemy a banco.db.
#   2. crear_tablas(app) asegura que las tablas existan (no hace nada si
#      ya existen — es seguro llamarlo en cada arranque).
#   3. Dentro de un contexto de aplicación, se siembra el admin por
#      defecto si hace falta, y Banco/GestorPrestamos/SucursalesManager
#      cargan sus datos reales desde banco.db.
#
# La siembra de USUARIOS de prueba (seed.py/seed_prestamos.py) YA NO se
# llama aquí — eso ahora es responsabilidad de seed_db.py, que se corre
# una sola vez, a mano, la primera vez que se configura el proyecto
# (Fase 11). Si necesitas volver a cargar esos datos de prueba, corre
# `python seed_db.py` por separado; api.py nunca los duplica ni los borra.
# =============================================================================
init_db(app)
crear_tablas(app)
migrate = Migrate(app, db)

with app.app_context():
    import administrador_repository as ar
    ar.sembrar_admin_por_defecto()

    # PULIDO: restaurar la última configuración de decoradores elegida por
    # el admin (antes de esto, siempre volvía a la config "3" por defecto
    # al reiniciar api.py — ver configurar_decoradores() más abajo).
    import configuracion_repository as cfg
    _CONFIGS_DECORADORES = {
        "1": ["tiempo"],
        "2": ["auditoria"],
        "3": ["tiempo", "auditoria"],
        "4": ["auditoria", "reintento"],
        "5": ["tiempo", "auditoria", "reintento"],
        "6": [],
    }
    _config_guardada = cfg.get("decoradores_config", "3")
    Transaccion.DECORADORES_ACTIVOS = _CONFIGS_DECORADORES.get(_config_guardada, ["tiempo", "auditoria"])

    # ── Estado global del servidor ────────────────────────────────────────────
    logger         = Logger.get_instancia()
    banco          = Banco()
    op_facade      = OperacionFacade(banco)
    usuario_facade = UsuarioFacade(banco)

    logger.log(
        f"¡Sistema Bancario Core iniciado vía API! "
        f"({len(banco.usuarios)} usuario(s) cargados desde banco.db)"
    )

from estado_cuenta import EstadoCuentaProducer
from command_transaccion import (
    ComandoDeposito, ComandoRetiro, ComandoTransferencia, HistorialComandos
)
from prestamo_strategy import (
    EstrategiaInteresProducer, GestorPrestamos, Prestamo
)


# =============================================================================
# HELPER
# =============================================================================

def ok(data=None, mensaje="Operación exitosa"):
    return jsonify({"ok": True, "mensaje": mensaje, "data": data})

def err(mensaje="Error en la operación", code=400):
    return jsonify({"ok": False, "mensaje": mensaje, "data": None}), code


# =============================================================================
# MANEJO GLOBAL DE ERRORES — FASE 3
# =============================================================================
# Toda falla devuelve el mismo formato JSON {ok, mensaje, data} que el resto
# de la API. Antes, un dato inválido o un error inesperado devolvía una
# página HTML de error 500 que el frontend no podía interpretar.
@app.errorhandler(ErrorValidacion)
def _manejar_validacion(e):
    return err(str(e), 400)


@app.errorhandler(HTTPException)
def _manejar_http(e):
    return err(e.description or e.name, e.code)


@app.errorhandler(Exception)
def _manejar_inesperado(e):
    if app.debug:
        raise e   # en modo desarrollo se conserva el traceback / depurador
    Logger.get_instancia().log(
        f"Error no controlado en {request.method} {request.path}: {e!r}",
        nivel="ERROR"
    )
    return err("Error interno del servidor.", 500)


# =============================================================================
# AUTENTICACIÓN — FASE 2
# =============================================================================
# Antes, login.html validaba usuario/contraseña completamente en el
# navegador (JS) y nunca avisaba al servidor. Ahora el servidor emite un
# token real tras validar credenciales, y ese token es lo que protege el
# resto de los endpoints (ver decorador @requiere_sesion en auth_session.py).
# =============================================================================

@app.route("/api/auth/login/admin", methods=["POST"])
def login_admin():
    body     = leer_json()
    usuario  = texto(body, "usuario")
    password = str(body.get("password", ""))

    if not SesionManager.get_instancia().validar_admin(usuario, password):
        return err("Usuario o contraseña incorrectos.", code=401)

    token = SesionManager.get_instancia().crear_sesion(rol="admin")
    return ok({"token": token, "rol": "admin"}, "Bienvenido, administrador.")


@app.route("/api/auth/login/usuario", methods=["POST"])
def login_usuario_endpoint():
    body          = leer_json()
    numero_cuenta = texto(body, "numero_cuenta")
    password      = str(body.get("password", ""))

    if not numero_cuenta or not password:
        return err("Número de cuenta y contraseña son obligatorios.")

    cuenta = banco.buscar_cuenta_por_numero(numero_cuenta)
    if not cuenta:
        return err("Número de cuenta o contraseña incorrectos.", code=401)

    titular = next(
        (u for u in banco.usuarios if any(c.numero == numero_cuenta for c in u.cuentas)),
        None
    )
    if not titular or not titular.verificar_password(password):
        return err("Número de cuenta o contraseña incorrectos.", code=401)

    token = SesionManager.get_instancia().crear_sesion(rol="usuario", cuenta=numero_cuenta)
    return ok(
        {"token": token, "rol": "usuario", "numero_cuenta": numero_cuenta},
        "Sesión iniciada correctamente."
    )


# =============================================================================
# LOGIN UNIFICADO — administrador y cliente comparten la misma puerta
# POST /api/auth/login
# Body: { "identificador": "admin" | "1001", "password": "..." }
#
# El servidor decide el rol:
#   - Si el identificador es un administrador registrado → rol "admin".
#   - Si no, se interpreta como número de cuenta → rol "usuario".
# El frontend solo redirige según el rol devuelto; nunca lo decide él.
# Mensaje de error genérico e idéntico en todos los fallos, para no revelar
# si el identificador existe o no.
# =============================================================================
@app.route("/api/auth/login", methods=["POST"])
def login_unificado():
    body          = leer_json()
    identificador = texto(body, "identificador")
    password      = str(body.get("password", ""))
    msg_error     = "Usuario o contraseña incorrectos."

    if not identificador or not password:
        return err("Completa todos los campos.")

    sesiones = SesionManager.get_instancia()

    # 1) ¿Es un administrador?
    import administrador_repository as ar
    if ar.existe(identificador):
        if not sesiones.validar_admin(identificador, password):
            return err(msg_error, code=401)
        token = sesiones.crear_sesion(rol="admin")
        return ok({"token": token, "rol": "admin"}, "Bienvenido, administrador.")

    # 2) Si no, es un cliente identificado por su número de cuenta.
    cuenta = banco.buscar_cuenta_por_numero(identificador)
    titular = next(
        (u for u in banco.usuarios
         if any(c.numero == identificador for c in u.cuentas)),
        None
    ) if cuenta else None

    if not titular or not titular.verificar_password(password):
        return err(msg_error, code=401)

    token = sesiones.crear_sesion(rol="usuario", cuenta=identificador)
    return ok(
        {"token": token, "rol": "usuario", "numero_cuenta": identificador},
        "Sesión iniciada correctamente."
    )


@app.route("/api/auth/logout", methods=["POST"])
def logout():
    header = request.headers.get("Authorization", "")
    token  = header[7:].strip() if header.startswith("Bearer ") else ""
    if token:
        SesionManager.get_instancia().cerrar_sesion(token)
    return ok(None, "Sesión cerrada.")


# =============================================================================
# 1. REGISTRAR USUARIO
# =============================================================================
@app.route("/api/usuarios/registrar", methods=["POST"])
@requiere_sesion(rol="admin")
def registrar_usuario():
    body = leer_json()
    nombre    = texto(body, "nombre")
    documento = texto(body, "documento")
    celular   = texto(body, "celular")
    correo    = texto(body, "correo")

    if not nombre or not documento:
        return err("Nombre y documento son obligatorios.")

    resultado = usuario_facade.registrar_usuario(nombre, documento, celular, correo)
    if resultado is None:
        return err(f"Ya existe un usuario con documento {documento}.")

    return ok(
        {"nombre": resultado.nombre, "documento": resultado.documento,
         "celular": resultado.celular, "correo": resultado.correo,
         "kyc": resultado.verificado_kyc},
        f"Usuario '{nombre}' registrado exitosamente."
    )


# =============================================================================
# 2. VERIFICAR KYC
# =============================================================================
@app.route("/api/usuarios/kyc", methods=["POST"])
@requiere_sesion(rol="admin")
def verificar_kyc():
    body = leer_json()
    documento = texto(body, "documento")

    if not documento:
        return err("El documento es obligatorio.")

    resultado = usuario_facade.verificar_kyc(documento)
    if not resultado:
        return err(f"No se encontró usuario con documento {documento}.")

    usuario = banco.buscar_usuario_por_documento(documento)
    return ok(
        {"nombre": usuario.nombre, "documento": usuario.documento,
         "kyc": usuario.verificado_kyc},
        f"KYC verificado para '{usuario.nombre}'."
    )


# =============================================================================
# 3. CREAR CUENTA
# =============================================================================
@app.route("/api/cuentas/crear", methods=["POST"])
@requiere_sesion(rol="admin")
def crear_cuenta():
    body = leer_json()
    documento       = texto(body, "documento")
    numero          = texto(body, "numero")
    tipo            = texto(body, "tipo", "corriente")
    saldo_inicial   = monto_valido(body, "saldo_inicial", minimo=0)
    indice_sucursal = entero(body, "indice_sucursal", 1, minimo=1, maximo=1000)

    if not documento or not numero:
        return err("Documento y número de cuenta son obligatorios.")

    cuenta = usuario_facade.crear_cuenta(documento, numero, tipo, saldo_inicial, indice_sucursal)
    if cuenta is None:
        return err("No se pudo crear la cuenta. Verifique KYC, duplicados y datos.")

    return ok(
        {"numero": cuenta.numero, "tipo": cuenta.tipo, "saldo": cuenta.saldo},
        f"Cuenta {numero} ({tipo}) creada exitosamente."
    )


# =============================================================================
# 4. DEPOSITAR
# =============================================================================
@app.route("/api/operaciones/depositar", methods=["POST"])
@requiere_sesion()
def depositar():
    body   = leer_json()
    numero = texto(body, "numero_cuenta")
    monto  = monto_valido(body, "monto")
    canal  = texto(body, "canal", "web")

    if not numero or monto <= 0:
        return err("Número de cuenta y monto positivo son obligatorios.")

    # FASE 2: un cliente solo puede depositar en SU PROPIA cuenta.
    if g.sesion["rol"] == "usuario" and g.sesion["cuenta"] != numero:
        return err("No puede operar sobre una cuenta que no es la suya.", code=403)

    cuenta = banco.buscar_cuenta_por_numero(numero)
    if not cuenta:
        return err(f"Cuenta {numero} no encontrada.")

    # ── COMMAND: encapsular y registrar en el Invoker ─────────────────────────
    cmd       = ComandoDeposito(cuenta, monto, canal)
    resultado = HistorialComandos.get_instancia().ejecutar(cmd)
    if not resultado["ok"]:
        return err(resultado["mensaje"])

    return ok(
        {"numero": numero, "saldo_actual": cuenta.saldo,
         "estado_invoker": HistorialComandos.get_instancia().get_estado()},
        f"Depósito de ${monto:,.2f} realizado exitosamente."
    )


# =============================================================================
# 5. RETIRAR
# =============================================================================
@app.route("/api/operaciones/retirar", methods=["POST"])
@requiere_sesion()
def retirar():
    body   = leer_json()
    numero = texto(body, "numero_cuenta")
    monto  = monto_valido(body, "monto")
    canal  = texto(body, "canal", "cajero")

    if not numero or monto <= 0:
        return err("Número de cuenta y monto positivo son obligatorios.")

    # FASE 2: un cliente solo puede retirar de SU PROPIA cuenta.
    if g.sesion["rol"] == "usuario" and g.sesion["cuenta"] != numero:
        return err("No puede operar sobre una cuenta que no es la suya.", code=403)

    cuenta = banco.buscar_cuenta_por_numero(numero)
    if not cuenta:
        return err(f"Cuenta {numero} no encontrada.")

    # ── COMMAND: encapsular y registrar en el Invoker ─────────────────────────
    cmd       = ComandoRetiro(cuenta, monto, canal)
    resultado = HistorialComandos.get_instancia().ejecutar(cmd)
    if not resultado["ok"]:
        return err(resultado["mensaje"])

    return ok(
        {"numero": numero, "saldo_actual": cuenta.saldo,
         "estado_invoker": HistorialComandos.get_instancia().get_estado()},
        f"Retiro de ${monto:,.2f} realizado exitosamente."
    )


# =============================================================================
# 6. TRANSFERIR
# =============================================================================
@app.route("/api/operaciones/transferir", methods=["POST"])
@requiere_sesion()
def transferir():
    body    = leer_json()
    origen  = texto(body, "numero_origen")
    destino = texto(body, "numero_destino")
    monto   = monto_valido(body, "monto")
    canal   = texto(body, "canal", "web")

    if not origen or not destino or monto <= 0:
        return err("Cuentas origen, destino y monto positivo son obligatorios.")

    # FASE 2: un cliente solo puede transferir DESDE su propia cuenta
    # (hacia cualquier destino, como en cualquier banca en línea real).
    if g.sesion["rol"] == "usuario" and g.sesion["cuenta"] != origen:
        return err("No puede transferir desde una cuenta que no es la suya.", code=403)

    c_orig = banco.buscar_cuenta_por_numero(origen)
    c_dest = banco.buscar_cuenta_por_numero(destino)
    if not c_orig:
        return err(f"Cuenta origen {origen} no encontrada.")
    if not c_dest:
        return err(f"Cuenta destino {destino} no encontrada.")

    # ── COMMAND: encapsular y registrar en el Invoker ─────────────────────────
    cmd       = ComandoTransferencia(c_orig, c_dest, monto, canal)
    resultado = HistorialComandos.get_instancia().ejecutar(cmd)
    if not resultado["ok"]:
        return err(resultado["mensaje"])

    return ok(
        {
            "origen":  {"numero": origen,  "saldo": c_orig.saldo},
            "destino": {"numero": destino, "saldo": c_dest.saldo},
            "estado_invoker": HistorialComandos.get_instancia().get_estado()
        },
        f"Transferencia de ${monto:,.2f} realizada exitosamente."
    )


# =============================================================================
# 7. CONSULTAR MOVIMIENTOS (historial de cuenta)
# =============================================================================
@app.route("/api/cuentas/movimientos/<numero>", methods=["GET"])
@requiere_sesion()
def consultar_movimientos(numero):
    # FASE 2: un cliente solo puede ver el historial de SU PROPIA cuenta.
    if g.sesion["rol"] == "usuario" and g.sesion["cuenta"] != numero:
        return err("No puede consultar una cuenta que no es la suya.", code=403)

    cuenta = banco.buscar_cuenta_por_numero(numero)
    if not cuenta:
        return err(f"Cuenta {numero} no encontrada.")

    return ok({
        "numero": cuenta.numero,
        "tipo": cuenta.tipo,
        "saldo": cuenta.saldo,
        "total_movimientos": len(cuenta.transacciones),
        "movimientos": cuenta.transacciones[-20:]
    }, "Movimientos obtenidos exitosamente.")


# =============================================================================
# 7B. CONSULTAR TITULAR DE UNA CUENTA (dato mínimo, para portal del cliente)
# =============================================================================
# FASE 1 — SEGURIDAD:
# Este endpoint existe para reemplazar el uso de GET /api/usuarios desde
# usuario.html. Antes, el portal del cliente descargaba la lista COMPLETA
# de usuarios (documento, celular, correo y saldos de TODAS las cuentas del
# banco) solo para mostrar el nombre del titular de una cuenta puntual.
#
# Este endpoint devuelve únicamente {numero, titular} — el mínimo dato
# necesario — y nada más. No expone documento, celular, correo ni saldos.
# =============================================================================
@app.route("/api/cuentas/titular/<numero>", methods=["GET"])
@requiere_sesion()
def consultar_titular(numero):
    cuenta = banco.buscar_cuenta_por_numero(numero)
    if not cuenta:
        return err(f"Cuenta {numero} no encontrada.")

    titular = None
    for u in banco.usuarios:
        if any(c.numero == numero for c in u.cuentas):
            titular = u.nombre
            break

    return ok(
        {"numero": cuenta.numero, "titular": titular or "—"},
        "Titular obtenido exitosamente."
    )


# =============================================================================
# 7C. CONSULTAR ESTADO KYC DE UNA CUENTA (dato mínimo, para portal del cliente)
# =============================================================================
# FASE 3: mismo criterio que /cuentas/titular — se expone solo lo mínimo
# necesario (si el KYC está verificado o no), nunca documento, celular,
# correo ni saldos. Un cliente solo puede consultar su propia cuenta;
# el admin puede consultar cualquiera.
# =============================================================================
@app.route("/api/cuentas/kyc/<numero>", methods=["GET"])
@requiere_sesion()
def consultar_kyc(numero):
    if g.sesion["rol"] == "usuario" and g.sesion["cuenta"] != numero:
        return err("No puede consultar el KYC de una cuenta que no es la suya.", code=403)

    cuenta = banco.buscar_cuenta_por_numero(numero)
    if not cuenta:
        return err(f"Cuenta {numero} no encontrada.")

    titular = next(
        (u for u in banco.usuarios if any(c.numero == numero for c in u.cuentas)),
        None
    )
    if not titular:
        return err("No se encontró el titular de esta cuenta.")

    return ok(
        {"numero": numero, "kyc_verificado": titular.verificado_kyc},
        "Estado KYC obtenido exitosamente."
    )


# =============================================================================
# 8. CONSULTAR SALDOS TOTALES DE USUARIO
# =============================================================================
@app.route("/api/usuarios/saldos/<documento>", methods=["GET"])
@requiere_sesion(rol="admin")
def saldos_usuario(documento):
    usuario = banco.buscar_usuario_por_documento(documento)
    if not usuario:
        return err(f"Usuario con documento {documento} no encontrado.")

    cuentas_data = [
        {"numero": c.numero, "tipo": c.tipo, "saldo": c.get_saldo_total()}
        for c in usuario.cuentas
    ]
    total = sum(c["saldo"] for c in cuentas_data)
    return ok({
        "nombre": usuario.nombre,
        "documento": usuario.documento,
        "cuentas": cuentas_data,
        "total": total
    }, "Saldos obtenidos exitosamente.")


# =============================================================================
# 9. VER TODOS LOS USUARIOS
# =============================================================================
# ✅ FASE 2: ya no es de acceso libre. Ahora exige una sesión de
# administrador válida (@requiere_sesion(rol="admin")). Antes (Fase 1)
# quedó documentado como pendiente; queda resuelto aquí.
# =============================================================================
@app.route("/api/usuarios", methods=["GET"])
@requiere_sesion(rol="admin")
def listar_usuarios():
    data = []
    for u in banco.usuarios:
        data.append({
            "nombre": u.nombre,
            "documento": u.documento,
            "celular": u.celular,
            "correo": u.correo,
            "kyc": u.verificado_kyc,
            "cuentas": [
                {"numero": c.numero, "tipo": c.tipo, "saldo": c.saldo}
                for c in u.cuentas
            ]
        })
    return ok(data, f"{len(data)} usuario(s) registrados.")


# =============================================================================
# 10. VER SUCURSALES Y CUENTAS
# =============================================================================
@app.route("/api/sucursales", methods=["GET"])
@requiere_sesion(rol="admin")
def listar_sucursales():
    manager = SucursalesManager.get_instancia()
    data = []
    for s in manager.sucursales:
        data.append({
            "nombre": s.nombre,
            "saldo_total": s.get_saldo_total(),
            "total_cuentas": len(s.cuentas),
            "cuentas": [
                {"numero": c.numero, "tipo": c.tipo, "saldo": c.saldo}
                for c in s.cuentas
            ]
        })
    return ok(data, "Sucursales obtenidas exitosamente.")


# =============================================================================
# 11. REGISTRAR PROTOTIPO
# =============================================================================
@app.route("/api/prototipos/registrar", methods=["POST"])
@requiere_sesion(rol="admin")
def registrar_prototipo():
    body          = leer_json()
    numero_cuenta = texto(body, "numero_cuenta")
    nombre_proto  = texto(body, "nombre_proto")

    if not numero_cuenta or not nombre_proto:
        return err("Número de cuenta y nombre del prototipo son obligatorios.")

    cuenta = banco.buscar_cuenta_por_numero(numero_cuenta)
    if not cuenta:
        return err(f"Cuenta {numero_cuenta} no encontrada.")

    try:
        CuentaPrototypeRegistry.registrar(nombre_proto, cuenta)
        return ok(
            {"nombre": nombre_proto, "tipo": cuenta.tipo, "saldo": cuenta.saldo},
            f"Cuenta {numero_cuenta} registrada como prototipo '{nombre_proto}'."
        )
    except ValueError as e:
        return err(str(e))


# =============================================================================
# 12. CLONAR CUENTA DESDE PROTOTIPO
# =============================================================================
@app.route("/api/prototipos/clonar", methods=["POST"])
@requiere_sesion(rol="admin")
def clonar_cuenta():
    body          = leer_json()
    nombre_proto  = texto(body, "nombre_proto")
    documento     = texto(body, "documento")
    nuevo_numero  = texto(body, "nuevo_numero")
    indice_suc    = entero(body, "indice_sucursal", 1, minimo=1, maximo=1000)

    if not nombre_proto or not documento or not nuevo_numero:
        return err("Prototipo, documento de usuario y nuevo número son obligatorios.")

    try:
        cuenta_origen = CuentaPrototypeRegistry.get(nombre_proto)
    except ValueError as e:
        return err(str(e))

    usuario = banco.buscar_usuario_por_documento(documento)
    if not usuario:
        return err(f"Usuario con documento {documento} no encontrado.")
    if not usuario.verificado_kyc:
        return err("El usuario debe tener KYC verificado.")
    if banco.buscar_cuenta_por_numero(nuevo_numero):
        return err(f"El número de cuenta {nuevo_numero} ya existe.")

    sucursales = SucursalesManager.get_instancia().sucursales
    if not (1 <= indice_suc <= len(sucursales)):
        return err(f"Índice de sucursal inválido. Rango: 1-{len(sucursales)}.")

    sucursal = sucursales[indice_suc - 1]

    try:
        cuenta_clonada = (
            CuentaBuilder()
            .numero(nuevo_numero)
            .asociar_usuario(usuario)
            .asociar_sucursal(sucursal)
            .clone_desde(cuenta_origen)
        )

        # ── FIX: cuentas clonadas quedaban huérfanas en la base de datos ────
        # clone_desde() ya suscribe ObservadorPersistencia al clon (igual
        # que build() con una cuenta nueva), pero ese observador solo
        # ACTUALIZA una fila que ya existe — nunca la crea. Sin este guardado
        # explícito (el mismo paso que usuario_facade.crear_cuenta() hace
        # para cuentas nuevas), la primera operación sobre la cuenta clonada
        # fallaba en silencio: se veía bien en memoria pero nunca llegaba a
        # banco.db.
        import cuenta_repository as cr
        cr.guardar(
            cuenta_clonada,
            documento=documento,
            sucursal_id=SucursalesManager.get_instancia().id_de(sucursal)
        )

        return ok(
            {
                "numero": cuenta_clonada.numero,
                "tipo": cuenta_clonada.tipo,
                "saldo": cuenta_clonada.saldo,
                "prototipo_origen": nombre_proto
            },
            f"Cuenta {nuevo_numero} clonada exitosamente desde '{nombre_proto}'."
        )
    except ValueError as e:
        return err(str(e))


# =============================================================================
# 13. CONFIGURAR DECORADORES
# =============================================================================
@app.route("/api/decoradores/configurar", methods=["POST"])
@requiere_sesion(rol="admin")
def configurar_decoradores():
    body = leer_json()
    config = texto(body, "config", "3")

    configuraciones = {
        "1": ["tiempo"],
        "2": ["auditoria"],
        "3": ["tiempo", "auditoria"],
        "4": ["auditoria", "reintento"],
        "5": ["tiempo", "auditoria", "reintento"],
        "6": [],
    }

    if config not in configuraciones:
        return err("Configuración inválida. Use 1-6.")

    Transaccion.DECORADORES_ACTIVOS = configuraciones[config]
    nuevos = Transaccion.DECORADORES_ACTIVOS

    # PULIDO: antes esta elección se perdía al reiniciar api.py (volvía
    # siempre a la config "3" por defecto). Se guarda el código elegido
    # ("1".."6") en vez de la lista, para no duplicar la tabla de arriba.
    import configuracion_repository as cfg
    cfg.set("decoradores_config", config)

    return ok(
        {"decoradores_activos": nuevos},
        f"Decoradores configurados: {nuevos if nuevos else 'Ninguno (modo directo)'}."
    )

@app.route("/api/decoradores/activos", methods=["GET"])
@requiere_sesion(rol="admin")
def obtener_decoradores():
    return ok(
        {"decoradores_activos": Transaccion.DECORADORES_ACTIVOS},
        "Decoradores obtenidos."
    )


# =============================================================================
# 14. TRAZABILIDAD (demostrar Decorator con procesar_sin_bridge)
# =============================================================================
@app.route("/api/decoradores/trazabilidad", methods=["POST"])
@requiere_sesion(rol="admin")
def trazabilidad():
    body   = leer_json()
    numero = texto(body, "numero_cuenta")
    monto  = monto_valido(body, "monto")
    canal  = texto(body, "canal", "web")
    tipo   = texto(body, "tipo", "deposito")

    if not numero or monto <= 0:
        return err("Número de cuenta y monto positivo son obligatorios.")

    cuenta = banco.buscar_cuenta_por_numero(numero)
    if not cuenta:
        return err(f"Cuenta {numero} no encontrada.")

    logs_antes = len(logger.get_logs())
    exito = Transaccion.procesar_sin_bridge(
        cuenta_origen=cuenta, monto=monto, canal=canal, tipo=tipo
    )
    logs_nuevos = logger.get_logs()[logs_antes:]

    return ok(
        {
            "exito": exito,
            "saldo_actual": cuenta.saldo,
            "decoradores_usados": Transaccion.DECORADORES_ACTIVOS,
            "logs_operacion": logs_nuevos
        },
        f"Trazabilidad ejecutada. Resultado: {'EXITOSA' if exito else 'RECHAZADA'}."
    )


# =============================================================================
# 15. ELIMINAR USUARIO
# =============================================================================
@app.route("/api/usuarios/eliminar", methods=["DELETE"])
@requiere_sesion(rol="admin")
def eliminar_usuario():
    body      = leer_json()
    documento = texto(body, "documento")

    if not documento:
        return err("El documento es obligatorio.")

    usuario = banco.buscar_usuario_por_documento(documento)
    if not usuario:
        return err(f"No se encontró usuario con documento {documento}.")

    info = {
        "nombre": usuario.nombre,
        "cuentas_eliminadas": len(usuario.cuentas)
    }

    resultado = usuario_facade.eliminar_usuario(documento)
    if not resultado:
        return err("No se pudo eliminar el usuario.")

    return ok(info, f"Usuario '{info['nombre']}' eliminado correctamente.")


# =============================================================================
# 16. VER LOGS
# =============================================================================
@app.route("/api/logs", methods=["GET"])
@requiere_sesion(rol="admin")
def ver_logs():
    logs = logger.get_logs()
    return ok({"logs": logs, "total": len(logs)}, f"{len(logs)} entradas de log.")


# =============================================================================
# UTILIDADES
# =============================================================================
# =============================================================================
# 17. REPORTE DE SUCURSALES (Observer + datos históricos)
# =============================================================================
@app.route("/api/reportes/sucursales", methods=["GET"])
@requiere_sesion(rol="admin")
def reporte_sucursales():
    from datetime import datetime, timedelta
    from sucursales_manager import SucursalesManager

    hoy = datetime.now().date()
    hace_30 = hoy - timedelta(days=29)

    manager = SucursalesManager.get_instancia()
    reporte = []

    for sucursal in manager.sucursales:
        # Recolectar todas las transacciones de las cuentas de esta sucursal
        movimientos_hoy   = []
        movimientos_mes   = []
        por_tipo_hoy      = {"deposito": 0, "retiro": 0, "transferencia": 0}
        por_tipo_mes      = {"deposito": 0, "retiro": 0, "transferencia": 0}
        por_canal_mes     = {"web": 0, "movil": 0, "cajero": 0}
        volumen_tipo_mes  = {"deposito": 0.0, "retiro": 0.0, "transferencia": 0.0}
        # Movimientos agrupados por día (últimos 30 días)
        dias = {}
        for i in range(30):
            d = (hace_30 + timedelta(days=i)).isoformat()
            dias[d] = 0

        for cuenta in sucursal.cuentas:
            for t in cuenta.transacciones:
                try:
                    fecha_dt = datetime.strptime(t["fecha"], "%Y-%m-%d %H:%M:%S")
                    fecha_d  = fecha_dt.date()
                except Exception:
                    continue

                tipo  = t.get("tipo", "deposito")
                canal = t.get("canal", "web")
                monto = t.get("monto", 0.0)

                # Hoy
                if fecha_d == hoy:
                    movimientos_hoy.append(t)
                    if tipo in por_tipo_hoy:
                        por_tipo_hoy[tipo] += 1

                # Último mes
                if fecha_d >= hace_30:
                    movimientos_mes.append(t)
                    if tipo in por_tipo_mes:
                        por_tipo_mes[tipo] += 1
                    if canal in por_canal_mes:
                        por_canal_mes[canal] += 1
                    if tipo in volumen_tipo_mes:
                        volumen_tipo_mes[tipo] += monto
                    clave = fecha_d.isoformat()
                    if clave in dias:
                        dias[clave] += 1

        reporte.append({
            "sucursal":        sucursal.nombre,
            "saldo_total":     sucursal.get_saldo_total(),
            "total_cuentas":   len(sucursal.cuentas),
            "hoy": {
                "total":    len(movimientos_hoy),
                "por_tipo": por_tipo_hoy,
            },
            "mes": {
                "total":       len(movimientos_mes),
                "por_tipo":    por_tipo_mes,
                "por_canal":   por_canal_mes,
                "volumen_tipo": volumen_tipo_mes,
                "por_dia":     [{"fecha": k, "cantidad": v} for k, v in sorted(dias.items())],
            }
        })

    return ok(reporte, f"Reporte de {len(reporte)} sucursal(es) generado.")


@app.route("/api/prototipos", methods=["GET"])
@requiere_sesion(rol="admin")
def listar_prototipos():
    nombres = CuentaPrototypeRegistry.listar()
    prototipos = []
    for n in nombres:
        p = CuentaPrototypeRegistry.get(n)
        prototipos.append({"nombre": n, "tipo": p.tipo, "saldo": p.saldo, "numero_base": p.numero})
    return ok(prototipos, f"{len(prototipos)} prototipo(s) registrados.")




# =============================================================================
# 18. LISTAR TODAS LAS CUENTAS CON SU ESTADO (STATE)
# =============================================================================
@app.route("/api/cuentas/estados", methods=["GET"])
@requiere_sesion(rol="admin")
def listar_estados_cuentas():
    data = []
    for usuario in banco.usuarios:
        for cuenta in usuario.cuentas:
            estado = cuenta.get_estado()
            data.append({
                "numero":      cuenta.numero,
                "tipo":        cuenta.tipo,
                "saldo":       cuenta.saldo,
                "usuario":     usuario.nombre,
                "documento":   usuario.documento,
                "estado":      estado.get_nombre(),
                "descripcion": estado.get_descripcion(),
                "color":       estado.get_color(),
            })
    return ok(data, f"{len(data)} cuenta(s) encontradas.")


# =============================================================================
# 19. CAMBIAR ESTADO DE UNA CUENTA (STATE)
# POST /api/cuentas/estado
# Body: { "numero_cuenta": "1001", "nuevo_estado": "bloqueada", "motivo": "..." }
# =============================================================================
@app.route("/api/cuentas/estado", methods=["POST"])
@requiere_sesion(rol="admin")
def cambiar_estado_cuenta():
    body         = leer_json()
    numero       = texto(body, "numero_cuenta")
    nuevo_estado = texto(body, "nuevo_estado")
    motivo       = texto(body, "motivo")

    if not numero or not nuevo_estado:
        return err("Número de cuenta y nuevo estado son obligatorios.")

    cuenta = banco.buscar_cuenta_por_numero(numero)
    if not cuenta:
        return err(f"Cuenta {numero} no encontrada.")

    estado_anterior = cuenta.get_estado().get_nombre()

    if estado_anterior == "cerrada":
        return err("La cuenta ya está cerrada (estado terminal). No se puede cambiar.")

    try:
        nuevo = EstadoCuentaProducer.get(nuevo_estado, motivo=motivo)
        cuenta.set_estado(nuevo)
    except ValueError as e:
        return err(str(e))

    return ok(
        {
            "numero":          numero,
            "estado_anterior": estado_anterior,
            "estado_nuevo":    cuenta.get_estado().get_nombre(),
            "descripcion":     cuenta.get_estado().get_descripcion(),
            "color":           cuenta.get_estado().get_color(),
        },
        f"Cuenta {numero}: {estado_anterior.upper()} → {nuevo_estado.upper()}."
    )


# =============================================================================
# 20. CONSULTAR ESTADO DE UNA CUENTA (STATE)
# GET /api/cuentas/estado/<numero>
# =============================================================================
@app.route("/api/cuentas/estado/<numero>", methods=["GET"])
@requiere_sesion()
def consultar_estado_cuenta(numero):
    cuenta = banco.buscar_cuenta_por_numero(numero)
    if not cuenta:
        return err(f"Cuenta {numero} no encontrada.")

    estado = cuenta.get_estado()
    perm_dep, msg_dep = estado.puede_depositar()
    perm_ret, msg_ret = estado.puede_retirar()
    perm_tra, msg_tra = estado.puede_transferir()

    return ok({
        "numero":      numero,
        "estado":      estado.get_nombre(),
        "descripcion": estado.get_descripcion(),
        "color":       estado.get_color(),
        "permisos": {
            "depositar":   {"permitido": perm_dep, "mensaje": msg_dep},
            "retirar":     {"permitido": perm_ret, "mensaje": msg_ret},
            "transferir":  {"permitido": perm_tra, "mensaje": msg_tra},
        }
    }, f"Estado de cuenta {numero} obtenido.")



# =============================================================================
# 21. CREAR PRÉSTAMO (STRATEGY)
# POST /api/prestamos/crear
# Body: { "documento": "123", "numero_cuenta": "1001", "monto": 5000000,
#         "num_cuotas": 12, "tasa_anual": 18.5, "tipo_interes": "fijo" }
# =============================================================================
@app.route("/api/prestamos/crear", methods=["POST"])
@requiere_sesion(rol="admin")
def crear_prestamo():
    body          = leer_json()
    documento     = texto(body, "documento")
    num_cuenta    = texto(body, "numero_cuenta")
    monto         = monto_valido(body, "monto")
    num_cuotas    = entero(body, "num_cuotas", 0, minimo=0, maximo=360)
    tasa_anual    = tasa_valida(body, "tasa_anual")
    tipo_interes  = texto(body, "tipo_interes", "fijo")

    if not documento or not num_cuenta or monto <= 0 or num_cuotas <= 0 or tasa_anual <= 0:
        return err("Todos los campos son obligatorios y deben ser positivos.")

    usuario = banco.buscar_usuario_por_documento(documento)
    if not usuario:
        return err(f"Usuario con documento {documento} no encontrado.")

    cuenta = banco.buscar_cuenta_por_numero(num_cuenta)
    if not cuenta:
        return err(f"Cuenta {num_cuenta} no encontrada.")

    # Verificar que la cuenta pertenece al usuario
    if not any(c.numero == num_cuenta for c in usuario.cuentas):
        return err(f"La cuenta {num_cuenta} no pertenece al usuario con documento {documento}.")

    try:
        estrategia = EstrategiaInteresProducer.get(tipo_interes)
    except ValueError as e:
        return err(str(e))

    prestamo = Prestamo(
        documento_usuario = documento,
        numero_cuenta     = num_cuenta,
        monto             = monto,
        num_cuotas        = num_cuotas,
        tasa_anual        = tasa_anual,
        estrategia        = estrategia,
    )

    # Depositar el monto del préstamo en la cuenta del usuario
    try:
        cuenta.depositar(monto, "web")
    except Exception as e:
        return err(f"No se pudo acreditar el préstamo en la cuenta: {e}")

    GestorPrestamos.get_instancia().agregar(prestamo)

    return ok(
        prestamo.to_dict(),
        f"Préstamo {prestamo.id} creado. ${monto:,.2f} acreditados en cuenta {num_cuenta}."
    )


# =============================================================================
# 22. LISTAR TODOS LOS PRÉSTAMOS (STRATEGY)
# GET /api/prestamos
# =============================================================================
@app.route("/api/prestamos", methods=["GET"])
@requiere_sesion()
def listar_prestamos():
    prestamos = GestorPrestamos.get_instancia().get_todos()
    resultado = []
    for p in prestamos:
        d = p.to_dict()
        # Enriquecer con nombre del usuario
        usuario = banco.buscar_usuario_por_documento(p.documento)
        d["nombre_usuario"] = usuario.nombre if usuario else "—"
        resultado.append(d)

    # FASE 2: antes esta lista se devolvía COMPLETA (préstamos de todos los
    # clientes) y usuario.html la filtraba solo en el navegador — cualquiera
    # podía ver los préstamos y montos de los demás inspeccionando la
    # respuesta cruda de la API. Ahora, si quien pregunta es un cliente
    # (no un admin), el servidor solo devuelve SUS PROPIOS préstamos.
    if g.sesion["rol"] == "usuario":
        resultado = [p for p in resultado if p.get("numero_cuenta") == g.sesion["cuenta"]]

    return ok(resultado, f"{len(resultado)} préstamo(s) registrados.")


# =============================================================================
# 23. REGISTRAR PAGO DE CUOTA (STRATEGY)
# POST /api/prestamos/pagar
# Body: { "prestamo_id": "AB12CD34" }
# =============================================================================
@app.route("/api/prestamos/pagar", methods=["POST"])
@requiere_sesion(rol="admin")
def pagar_cuota():
    body        = leer_json()
    prestamo_id = texto(body, "prestamo_id").upper()

    if not prestamo_id:
        return err("ID del préstamo es obligatorio.")

    prestamo = GestorPrestamos.get_instancia().get_por_id(prestamo_id)
    if not prestamo:
        return err(f"Préstamo {prestamo_id} no encontrado.")

    if prestamo.estado == "pagado":
        return err("El préstamo ya está completamente pagado.")

    cuenta = banco.buscar_cuenta_por_numero(prestamo.numero_cuenta)
    if not cuenta:
        return err(f"Cuenta {prestamo.numero_cuenta} no encontrada.")

    # ── CORRECCIÓN: calcular cuánto falta realmente descontando abonos libres
    monto_real = prestamo.calcular_monto_real_cuota()

    if monto_real == 0.0:
        # Los abonos ya cubrieron esta cuota completa — solo registrar sin cobrar
        resultado = prestamo.registrar_pago(0.0)
        if not resultado["ok"]:
            return err(resultado["mensaje"])

        # FASE 12: Prestamo no tiene un Observer como Cuenta — hay que
        # persistir el cambio explícitamente después de cada mutación.
        GestorPrestamos.get_instancia().guardar(prestamo)

        return ok(
            {
                "prestamo_id":       prestamo_id,
                "cuota_pagada":      resultado["pago"],
                "monto_cobrado":     0.0,
                "abonos_aplicados":  resultado["pago"].get("abonos_aplicados", 0),
                "estado_prestamo":   prestamo.estado,
                "cuotas_pagadas":    prestamo.cuotas_pagadas,
                "cuotas_restantes":  prestamo.num_cuotas - prestamo.cuotas_pagadas,
                "saldo_cuenta":      cuenta.saldo,
                "total_pagado":      prestamo.total_pagado,
            },
            f"Cuota {prestamo.cuotas_pagadas}/{prestamo.num_cuotas} cubierta por abonos previos — sin cobro adicional."
        )

    # Validar saldo solo por el monto real a cobrar
    if cuenta.saldo < monto_real:
        return err(
            f"Saldo insuficiente. Saldo: ${cuenta.saldo:,.2f} | "
            f"Cuota completa: ${prestamo.cuota_mensual:,.2f} | "
            f"Ya abonado: ${prestamo.cuota_mensual - monto_real:,.2f} | "
            f"Falta cobrar: ${monto_real:,.2f}"
        )

    # Debitar solo el monto real (cuota - abonos ya aplicados)
    try:
        cuenta.retirar(monto_real, "web")
    except Exception as e:
        return err(f"No se pudo debitar la cuota: {e}")

    resultado = prestamo.registrar_pago(monto_real)
    if not resultado["ok"]:
        cuenta.depositar(monto_real, "web")
        return err(resultado["mensaje"])

    # FASE 12: persistir el préstamo (ver nota arriba).
    GestorPrestamos.get_instancia().guardar(prestamo)

    abonos_aplicados = resultado["pago"].get("abonos_aplicados", 0)
    msg = (
        f"Cuota {prestamo.cuotas_pagadas}/{prestamo.num_cuotas} registrada. "
        f"Cobrado: ${monto_real:,.2f}"
        + (f" (${abonos_aplicados:,.2f} cubiertos por abonos previos)." if abonos_aplicados > 0 else ".")
    )

    return ok(
        {
            "prestamo_id":       prestamo_id,
            "cuota_pagada":      resultado["pago"],
            "monto_cobrado":     monto_real,
            "abonos_aplicados":  abonos_aplicados,
            "estado_prestamo":   prestamo.estado,
            "cuotas_pagadas":    prestamo.cuotas_pagadas,
            "cuotas_restantes":  prestamo.num_cuotas - prestamo.cuotas_pagadas,
            "saldo_cuenta":      cuenta.saldo,
            "total_pagado":      prestamo.total_pagado,
        },
        msg
    )



# =============================================================================
# 25. ABONO MANUAL AL PRÉSTAMO (STRATEGY)
# POST /api/prestamos/abonar
# Body: { "prestamo_id": "AB12CD34", "monto": 300000 }
# Registra cualquier monto como abono libre, lo descuenta de la cuenta
# y lo acumula en total_pagado del préstamo.
# =============================================================================
@app.route("/api/prestamos/abonar", methods=["POST"])
@requiere_sesion(rol="admin")
def abonar_prestamo():
    body        = leer_json()
    prestamo_id = texto(body, "prestamo_id").upper()
    monto       = monto_valido(body, "monto")

    if not prestamo_id:
        return err("ID del préstamo es obligatorio.")
    if monto <= 0:
        return err("El monto del abono debe ser positivo.")

    prestamo = GestorPrestamos.get_instancia().get_por_id(prestamo_id)
    if not prestamo:
        return err(f"Préstamo {prestamo_id} no encontrado.")

    if prestamo.estado == "pagado":
        return err("El préstamo ya está completamente pagado.")

    cuenta = banco.buscar_cuenta_por_numero(prestamo.numero_cuenta)
    if not cuenta:
        return err(f"Cuenta {prestamo.numero_cuenta} no encontrada.")

    if cuenta.saldo < monto:
        return err(
            f"Saldo insuficiente. Saldo: ${cuenta.saldo:,.2f} | "
            f"Abono solicitado: ${monto:,.2f}"
        )

    # Ajustar si el abono supera lo que queda por pagar
    saldo_prestamo = round(prestamo.total_a_pagar - prestamo.total_pagado, 2)
    if monto > saldo_prestamo:
        monto = saldo_prestamo  # no cobrar más de lo que se debe

    try:
        cuenta.retirar(monto, "web")
    except Exception as e:
        return err(f"No se pudo debitar el abono: {e}")

    resultado = prestamo.registrar_abono_manual(monto)
    if not resultado["ok"]:
        cuenta.depositar(monto, "web")
        return err(resultado["mensaje"])

    # FASE 12: persistir el préstamo (ver nota en pagar_cuota más arriba).
    GestorPrestamos.get_instancia().guardar(prestamo)

    saldo_pendiente = round(prestamo.total_a_pagar - prestamo.total_pagado, 2)

    return ok(
        {
            "prestamo_id":     prestamo_id,
            "abono":           resultado["pago"],
            "total_pagado":    resultado["total_pagado"],
            "total_a_pagar":   resultado["total_a_pagar"],
            "saldo_pendiente": saldo_pendiente,
            "estado_prestamo": prestamo.estado,
            "saldo_cuenta":    cuenta.saldo,
        },
        f"Abono de ${monto:,.2f} registrado en préstamo {prestamo_id}."
    )


# =============================================================================
# 24. COMPARAR ESTRATEGIAS (STRATEGY) — utilidad para el frontend
# POST /api/prestamos/comparar
# Body: { "monto": 5000000, "num_cuotas": 12, "tasa_anual": 18.5 }
# =============================================================================
@app.route("/api/prestamos/comparar", methods=["POST"])
@requiere_sesion(rol="admin")
def comparar_estrategias():
    body       = leer_json()
    monto      = monto_valido(body, "monto")
    num_cuotas = entero(body, "num_cuotas", 0, minimo=0, maximo=360)
    tasa_anual = tasa_valida(body, "tasa_anual")

    if monto <= 0 or num_cuotas <= 0 or tasa_anual <= 0:
        return err("Monto, cuotas y tasa deben ser positivos.")

    resultado = []
    for tipo in EstrategiaInteresProducer.listar():
        estrategia = EstrategiaInteresProducer.get(tipo)
        resultado.append({
            "tipo":             tipo,
            "nombre":           estrategia.get_nombre(),
            "descripcion":      estrategia.get_descripcion(),
            "cuota_mensual":    estrategia.calcular_cuota(monto, tasa_anual, num_cuotas),
            "total_intereses":  estrategia.calcular_total_intereses(monto, tasa_anual, num_cuotas),
            "total_a_pagar":    round(monto + estrategia.calcular_total_intereses(monto, tasa_anual, num_cuotas), 2),
        })

    return ok(resultado, "Comparación de estrategias calculada.")



# =============================================================================
# ENDPOINTS PATRÓN COMMAND
# =============================================================================

# 26. DESHACER ÚLTIMO COMANDO
@app.route("/api/command/deshacer", methods=["POST"])
@requiere_sesion(rol="admin")
def command_deshacer():
    invoker   = HistorialComandos.get_instancia()
    resultado = invoker.deshacer()
    if not resultado["ok"]:
        return err(resultado["mensaje"])
    return ok(
        {**resultado["datos"], "estado_invoker": invoker.get_estado()},
        resultado["mensaje"]
    )


# 27. REEJECUTAR ÚLTIMO DESHECHO
@app.route("/api/command/reejecutar", methods=["POST"])
@requiere_sesion(rol="admin")
def command_reejecutar():
    invoker   = HistorialComandos.get_instancia()
    resultado = invoker.reejecutar()
    if not resultado["ok"]:
        return err(resultado["mensaje"])
    return ok(
        {**resultado["datos"], "estado_invoker": invoker.get_estado()},
        resultado["mensaje"]
    )


# 28. HISTORIAL DE COMANDOS
@app.route("/api/command/historial", methods=["GET"])
@requiere_sesion(rol="admin")
def command_historial():
    invoker   = HistorialComandos.get_instancia()
    historial = invoker.get_historial()
    estado    = invoker.get_estado()
    return ok(
        {"historial": historial, "estado": estado},
        f"{len(historial)} comando(s) en historial."
    )


# 29. LIMPIAR HISTORIAL
@app.route("/api/command/limpiar", methods=["POST"])
@requiere_sesion(rol="admin")
def command_limpiar():
    HistorialComandos.get_instancia().limpiar()
    return ok(None, "Historial de commands limpiado.")

if __name__ == "__main__":
    # debug=True expone la consola interactiva de Werkzeug (ejecución de código
    # remoto si el servidor es alcanzable). Solo se activa de forma explícita:
    #   CMD:        set FLASK_DEBUG=1 && python api.py
    #   PowerShell: $env:FLASK_DEBUG="1"; python api.py
    app.run(debug=os.environ.get("FLASK_DEBUG", "0") == "1", port=5000)