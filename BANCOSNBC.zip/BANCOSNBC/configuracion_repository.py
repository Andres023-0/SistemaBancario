"""
=============================================================================
REPOSITORIO DE CONFIGURACIÓN DEL SISTEMA
=============================================================================
Clave/valor genérico para ajustes simples que antes vivían como atributos
de clase en memoria — hoy en día, principalmente Transaccion.DECORADORES_ACTIVOS
(ver operacion_decorator.py / api.py).
=============================================================================
"""

import models
from database import db


def get(clave: str, default: str = None) -> str:
    fila = db.session.get(models.ConfiguracionSistema, clave)
    return fila.valor if fila else default


def set(clave: str, valor: str) -> None:
    fila = db.session.get(models.ConfiguracionSistema, clave)
    if fila is None:
        fila = models.ConfiguracionSistema(clave=clave)
        db.session.add(fila)
    fila.valor = valor
    db.session.commit()
