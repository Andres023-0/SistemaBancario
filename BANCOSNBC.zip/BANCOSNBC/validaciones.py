"""
=============================================================================
VALIDACIÓN DE ENTRADAS DE LA API — FASE 3
=============================================================================
Antes, los endpoints hacían float(body.get("monto", 0)), int(...) y
body.get("x", "").strip() directamente sobre lo que llegara en el JSON. Un
dato mal formado ("abc", null, una lista, NaN, un número gigante) producía
una excepción no controlada y la API respondía 500 con HTML.

Este módulo centraliza el parseo y la validación:
  - Los montos se interpretan con Decimal (exacto), no con float, y se
    rechazan valores no numéricos, NaN/Infinity, más de 2 decimales o
    fuera del rango que soporta la base de datos (Numeric(14,2)).
  - Cualquier dato inválido lanza ErrorValidacion, que api.py convierte en
    una respuesta JSON 400 con un mensaje claro.

Los helpers son permisivos con los campos AUSENTES (devuelven "" / 0) para
que sigan funcionando los mensajes "campo obligatorio" que ya existían en
cada endpoint; solo rechazan datos presentes pero inválidos.
=============================================================================
"""

import math
from decimal import Decimal, InvalidOperation, ROUND_DOWN

# Límites alineados con las columnas de models.py
MAX_MONTO = Decimal("999999999999.99")   # Numeric(14, 2)
MAX_TASA  = Decimal("99.9999")           # Numeric(6, 4)
MAX_TEXTO = 100

_CENTAVO  = Decimal("0.01")
_DIEZMIL  = Decimal("0.0001")


class ErrorValidacion(ValueError):
    """Dato de entrada inválido. api.py lo responde como HTTP 400."""


# ─────────────────────────────────────────────────────────────────────────────
# Cuerpo de la petición
# ─────────────────────────────────────────────────────────────────────────────
def leer_json() -> dict:
    from flask import request
    body = request.get_json(silent=True)
    if not isinstance(body, dict):
        raise ErrorValidacion("El cuerpo de la petición debe ser un objeto JSON válido.")
    return body


# ─────────────────────────────────────────────────────────────────────────────
# Texto
# ─────────────────────────────────────────────────────────────────────────────
def texto(body: dict, campo: str, defecto: str = "", max_len: int = MAX_TEXTO) -> str:
    """Devuelve el campo como str sin espacios. Acepta str o int (ej. número de cuenta)."""
    valor = body.get(campo, defecto)
    if valor is None:
        valor = defecto
    if isinstance(valor, bool) or not isinstance(valor, (str, int)):
        raise ErrorValidacion(f"El campo '{campo}' debe ser texto.")
    valor = str(valor).strip()
    if len(valor) > max_len:
        raise ErrorValidacion(f"El campo '{campo}' no puede superar {max_len} caracteres.")
    return valor


# ─────────────────────────────────────────────────────────────────────────────
# Números
# ─────────────────────────────────────────────────────────────────────────────
def _a_decimal(valor, campo: str) -> Decimal:
    """Convierte lo recibido a Decimal finito. Ausente / "" → 0."""
    if valor is None or (isinstance(valor, str) and valor.strip() == ""):
        return Decimal(0)
    if isinstance(valor, bool):
        raise ErrorValidacion(f"El campo '{campo}' debe ser numérico.")
    if isinstance(valor, float):
        if not math.isfinite(valor):
            raise ErrorValidacion(f"El campo '{campo}' debe ser un número finito.")
        return Decimal(str(valor))
    if isinstance(valor, int):
        return Decimal(valor)
    if isinstance(valor, str):
        try:
            d = Decimal(valor.strip())
        except InvalidOperation:
            raise ErrorValidacion(f"El campo '{campo}' debe ser numérico.")
        if not d.is_finite():
            raise ErrorValidacion(f"El campo '{campo}' debe ser un número finito.")
        return d
    raise ErrorValidacion(f"El campo '{campo}' debe ser numérico.")


def monto_valido(body: dict, campo: str = "monto", minimo=None) -> float:
    """
    Monto en pesos: máximo 2 decimales y dentro del rango de la BD.
    Devuelve float (el dominio ya convierte a Decimal con ROUND_HALF_UP), pero
    solo después de comprobar con Decimal que el valor es exacto: con ≤ 14
    dígitos significativos, Decimal(str(float(d))) == d.
    Un monto <= 0 NO se rechaza aquí (cada endpoint conserva su mensaje);
    usar minimo=0 para campos como saldo_inicial, donde lo negativo es error.
    """
    d = _a_decimal(body.get(campo), campo)
    if abs(d) > MAX_MONTO:
        raise ErrorValidacion(f"El campo '{campo}' excede el máximo permitido (${MAX_MONTO:,.2f}).")
    if d != d.quantize(_CENTAVO, rounding=ROUND_DOWN):
        raise ErrorValidacion(f"El campo '{campo}' admite como máximo 2 decimales.")
    if minimo is not None and d < Decimal(str(minimo)):
        raise ErrorValidacion(f"El campo '{campo}' no puede ser menor que {minimo}.")
    return float(d)


def tasa_valida(body: dict, campo: str = "tasa_anual") -> float:
    """Tasa porcentual (ej. 18.5): máximo 4 decimales y < 100."""
    d = _a_decimal(body.get(campo), campo)
    if abs(d) > MAX_TASA:
        raise ErrorValidacion(f"El campo '{campo}' debe ser menor que 100.")
    if d != d.quantize(_DIEZMIL, rounding=ROUND_DOWN):
        raise ErrorValidacion(f"El campo '{campo}' admite como máximo 4 decimales.")
    return float(d)


def entero(body: dict, campo: str, defecto: int = 0, minimo=None, maximo=None) -> int:
    """Entero estricto: acepta 12, "12" o 12.0; rechaza 12.5, "abc", True, listas."""
    valor = body.get(campo)
    if valor is None or (isinstance(valor, str) and valor.strip() == ""):
        return defecto
    if isinstance(valor, bool):
        raise ErrorValidacion(f"El campo '{campo}' debe ser un número entero.")
    if isinstance(valor, int):
        n = valor
    elif isinstance(valor, float):
        if not math.isfinite(valor) or not valor.is_integer():
            raise ErrorValidacion(f"El campo '{campo}' debe ser un número entero.")
        n = int(valor)
    elif isinstance(valor, str):
        try:
            n = int(valor.strip())
        except ValueError:
            raise ErrorValidacion(f"El campo '{campo}' debe ser un número entero.")
    else:
        raise ErrorValidacion(f"El campo '{campo}' debe ser un número entero.")
    if minimo is not None and n < minimo:
        raise ErrorValidacion(f"El campo '{campo}' no puede ser menor que {minimo}.")
    if maximo is not None and n > maximo:
        raise ErrorValidacion(f"El campo '{campo}' no puede ser mayor que {maximo}.")
    return n
